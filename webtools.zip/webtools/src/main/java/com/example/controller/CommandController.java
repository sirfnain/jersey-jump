package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@Controller
@RequestMapping("/command")
public class CommandController {

    @GetMapping
    public String commandPage(Model model) {
        model.addAttribute("pageTitle", "Command Execution");
        return "command";
    }

    @PostMapping("/execute")
    @ResponseBody
    public String executeCommand(@RequestParam String script) {
        StringBuilder output = new StringBuilder();
        
        try {
            // Configure the SSH command to execute the Perl script on Linux host
            // Note: Replace these with actual host details and proper authentication
            ProcessBuilder processBuilder = new ProcessBuilder(
                "ssh",
                "user@linux-host",
                "perl",
                script
            );
            
            Process process = processBuilder.start();
            
            // Read the output
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            
            // Read any errors
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append("ERROR: ").append(line).append("\n");
                }
            }
            
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                output.append("\nProcess exited with code ").append(exitCode);
            }
            
        } catch (Exception e) {
            output.append("Error executing command: ").append(e.getMessage());
        }
        
        return output.toString();
    }
}